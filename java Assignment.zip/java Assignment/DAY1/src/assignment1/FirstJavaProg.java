package assignment1;

public class FirstJavaProg {
	public static void main(String[] args) {
		System.out.println("Hello Cybage!");
	}

}

package assignment2;

public class DataTypeSize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Integer.BYTES);
		System.out.println(Float.BYTES);
		System.out.println(Short.BYTES);
		System.out.println(Character.BYTES);
		

	}

}

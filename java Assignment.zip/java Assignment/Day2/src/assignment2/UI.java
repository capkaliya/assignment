package assignment2;

public class UI {

	public static void main(String[] args) {
		Date d1 = new Date();
		System.out.println(d1.getDay());
		System.out.println(d1.getMonth());
		System.out.println(d1.getYear());
		Date d2 = new Date("Monday","February",2020);
		System.out.println(d2.toString());

	}

}

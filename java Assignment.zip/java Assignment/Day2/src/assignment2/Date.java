package assignment2;

public class Date {
	private String day="Tuesday";
	private String month="january";
	private int year=2020;
	
	public Date() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Date(String day, String month, int year) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
	}

	public String getDay() {
		return day;
	}

	

	public String getMonth() {
		return month;
	}


	public int getYear() {
		return year;
	}

	public String toString() {
		return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
	}
	
	

}

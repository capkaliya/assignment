package assignment3;

public class NumberSum {
	public Integer sum(int number) {
		int sum=0;
		int temp = number;
		while(temp>0){ 
		int place = temp%10;
		temp=temp/10;
		sum+=place;
		}
		return sum;
		
	}
	

}

package assignment3;

import java.util.Scanner;

public class TestData {
	
	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)){
		System.out.println("Enter a number between 0 to 1000");
		int number = sc.nextInt();
		NumberSum num = new NumberSum();
		int intSum = num.sum(number);
		System.out.println(intSum);
		
		
	}
	}
}

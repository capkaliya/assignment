package assignment4;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)){
			
			IndividualDigits id = new IndividualDigits();
			System.out.println("Enter the Number");
			id.printDigit(sc.nextInt());
		}
		

	}

}

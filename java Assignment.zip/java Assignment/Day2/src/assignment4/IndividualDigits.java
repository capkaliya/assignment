package assignment4;

import java.util.ArrayList;

public class IndividualDigits {
	public void printDigit(int number){
		int temp = number;
		ArrayList<Integer> digit = new ArrayList<>(); 
		while(temp>0){ 
		int place = temp%10;
		digit.add(place);
		temp=temp/10;
		}
		for(int i=digit.size()-1; i>=0; i-- )
		System.out.print(digit.get(i)+" ");
	}

}

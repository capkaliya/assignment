package assignment1;

public class Employee {
	private int Id;
	private String Name;
	private String Address;
	private long Mob_No;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

//	public Employee(int id, String name, String address, long mob_No) {
//		super();
//		Id = id;
//		Name = name;
//		Address = address;
//		Mob_No = mob_No;
//	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public long getMob_No() {
		return Mob_No;
	}

	public void setMob_No(long mob_No) {
		Mob_No = mob_No;
	}

	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Address=" + Address
				+ ", Mob_No=" + Mob_No + "]";
	}
	
	

}


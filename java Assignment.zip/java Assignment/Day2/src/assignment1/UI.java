package assignment1;

public class UI {
	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.setId(101);
		e1.setName("Mahesh");
		e1.setAddress("Pune");
		e1.setMob_No(256342345L);
		System.out.println(e1.getId());
		System.out.println(e1.getName());
		System.out.println(e1.getAddress());
		System.out.println(e1.getMob_No());

	}
}
